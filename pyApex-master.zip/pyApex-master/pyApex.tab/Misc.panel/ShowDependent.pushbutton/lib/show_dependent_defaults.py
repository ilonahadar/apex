# -*- coding: utf-8 -*-

exceptions = [
    "Levels",
    "Work Plane Grid",
    "Viewports",
    "Other",
    "Sun Path",
    "Automatic Sketch Dimensions",
    "<Sketch>",
    "<Area Boundary>",
    "Constraints",
]

limit = 10
