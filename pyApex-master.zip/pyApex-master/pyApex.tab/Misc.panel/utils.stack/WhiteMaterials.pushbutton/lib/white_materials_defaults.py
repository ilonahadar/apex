# -*- coding: utf-8 -*-
import pyapex_utils
exceptions = [
    "Glass",
]
material = "Default"
ignore_transparent = True
