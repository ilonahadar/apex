# -*- coding: utf-8 -*-
import tempfile
import os
temp_dir = os.path.join(tempfile.gettempdir(), "pyApex_purgeFamilies")